<?php
include 'topbot/head.php'
?>

<body id="page-top">

    <?php
    include 'barSelect/sideView.php';
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <?php
            include 'barSelect/nav.php';
            ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <div class="row">

                    <div class="col-lg-12">

                        <!-- Tabel Bobot -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">View Matrix Keputusan</h6>
                            </div>
                            <div class="card-body">
                                <div class="my-2"></div>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>ID Penilaian</th>
                                            <th>ID Daerah</th>
                                            <th>Alternatif</th>
                                            <th>ID Kriteria</th>
                                            <th>Nama Kriteria</th>
                                            <th>ID Bobot</th>
                                            <th>Value Bobot</th>
                                            <th>Nilai</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;
                                        include "config.php";
                                        $a = "SELECT `tabel_penilaian`.`id_penilaian` AS `id_penilaian`,`tabel_alternatif`.`id_daerah` AS `id_daerah`,`tabel_alternatif`.`nm_daerah` AS `nm_daerah`,`tabel_kriteria`.`id_kriteria` AS `id_kriteria`,`tabel_kriteria`.`nm_kriteria` AS `nm_kriteria`,`tabel_bobot`.`id_bobot` AS `id_bobot`,`tabel_bobot`.`valuebobot` AS `valuebobot`,`tabel_penilaian`.`value` AS `nilai`
FROM (((`tabel_penilaian`
JOIN `tabel_bobot`)
JOIN `tabel_kriteria`)
JOIN `tabel_alternatif`)
WHERE ((`tabel_penilaian`.`id_daerah` = `tabel_alternatif`.`id_daerah`) AND (`tabel_penilaian`.`id_bobot` = `tabel_bobot`.`id_bobot`) AND (`tabel_kriteria`.`id_kriteria` = `tabel_bobot`.`id_kriteria`))";
                                        $b = $con->query($a);
                                        while ($c = $b->fetch_row()) {
                                        ?>
                                            <tr>
                                                <td><?php echo $no++; ?></td>
                                                <td><?php echo $c[0]; ?></td>
                                                <td><?php echo $c[1]; ?></td>
                                                <td><?php echo $c[2]; ?></td>
                                                <td><?php echo $c[3]; ?></td>
                                                <td><?php echo $c[4]; ?></td>
                                                <td><?php echo $c[5]; ?></td>
                                                <td><?php echo $c[6]; ?></td>
                                                <td><?php echo $c[7]; ?></td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>

                </div>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <?php
        include 'barSelect/copyright.php';
        ?>

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <?php
    include 'topbot/foot.php';
    ?>