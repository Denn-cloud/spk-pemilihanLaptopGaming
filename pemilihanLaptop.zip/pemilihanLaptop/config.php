<?php 
    $host = "127.0.0.1";
    $username = "root";
    $password = "";
    $database = "dss_pertanian";
    $con = mysqli_connect($host, $username, $password, $database);

?>
