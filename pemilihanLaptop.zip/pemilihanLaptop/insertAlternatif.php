<?php
include 'topbot/head.php';
?>

<body id="page-top">

    <?php
    include 'barSelect/sideInsert.php';
    ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <?php
            include 'barSelect/nav.php';
            ?>

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <div class="row">

                    <div class="col-lg-12">

                        <!-- Tambah Alternatif -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Tambah Alternatif</h6>
                            </div>
                            <div class="card-body">
                                <form action="proses/prosesAlternatif.php" method="POST">
                                    <div class="row mb-3">
                                        <label for="inputEmail3" class="col-sm-2 col-form-label">Nama Alternatif</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="nm_daerah">
                                        </div>
                                    </div>
                                    <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                                </form>
                            </div>
                        </div>

                    </div>

                </div>


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <?php
        include 'barSelect/copyright.php';
        ?>

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php
    include 'topbot/foot.php';
    ?>